

#'@title Get the description of a Distribution object
#'
#'@param object The object to describe
#'
#'@export
setGeneric('get.description',
           function(object){standardGeneric('get.description')})
